﻿#include <stdio.h>
#include <stdlib.h>
#pragma warning(disable:4996);
#include <fstream>//ifstream读文件，ofstream写文件，fstream读写文件
#include <string>//文本对象，储存读取的内容
#include <iostream>//屏幕输出cout
#include <cstdlib>//调用system("pause");

#include <iostream>
#include <stdint.h>
#include <cstring>
#include <time.h>
using namespace std;
#include <iostream>
#include "stdlib.h"
#define M 1024
#define N 1024
#define n 18
#define opera_num 9
int path[M * M][opera_num] = { 0 };
int B1[4][4] = { }, B2[4][4] = { }, B3[4][4] = { }, B4[4][4] = { }, B5[4][4] = { }, B6[4][4] = { }, B7[4][4] = { }, B8[4][4] = { };
int Temp1[4][4] = { }, Temp2[4][4] = { }, Temp3[4][4] = { }, Temp4[4][4] = { }, Temp5[4][4] = { }, Temp6[4][4] = { }, Temp7[4][4] = { }, Temp8[4][4] = { };
int R1[13][4] = { }, R2[13][4] = { }, R3[13][4] = { }, R4[13][4] = { }, R5[13][4] = { }, R6[13][4] = { }, R7[13][4] = { }, R8[13][4] = { };
int D1[4] = { }, D2[4] = { }, D3[4] = { }, D4[4] = { }, D5[4] = { }, D6[4] = { }, D7[4] = { }, D8[4] = { };
int E1[13] = {}, E2[13] = {}, E3[13] = {}, E4[13] = {}, E5[13] = {}, E6[13] = {}, E7[13] = {}, E8[13] = {};
int B[4][4] = { 1,0,0,0,0,1,0,0,0,0,1,1,0,0,0,1 }, R[13][4] = { 1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,1,1, }, D[4] = { 0,0,1,0 }, E[13] = { 0,0,0,0,1 };
int copy_type[48][3] = {
	0,0,0,
	1,1,0,
	2,2,0,
	3,3,0,
	4,0,1,
	5,1,1,
	6,2,1,
	7,3,1,
	8,0,2,
	9,1,2,
	10,2,2,
	11,3,2,
	12,0,3,
	13,1,3,
	14,2,3,
	15,3,3,
	16,0,4,
	17,1,4,
	18,2,4,
	19,3,4,
	20,0,5,
	21,1,5,
	22,2,5,
	23,3,5,
	24,0,6,
	25,1,6,
	26,2,6,
	27,3,6,
	28,0,7,
	29,1,7,
	30,2,7,
	31,3,7,
	32,0,8,
	33,1,8,
	34,2,8,
	35,3,8,
	36,0,9,
	37,1,9,
	38,2,9,
	39,3,9,
	40,0,10,
	41,1,10,
	42,2,10,
	43,3,10,
	44,0,11,
	45,1,11,
	46,2,11,
	47,3,11,
};
// There are $12$ different elementary matrices of Type $\rm{III}$ for
//$4\times 4$ matrices over $\mathbb{F}_{2^n}$
int Integer_power(int num);
int MDS(int Matrix_A[4][4][N]);
void addoper(int alpha_1[N], int alpha_2[N], int alpha_3[N]);
void multoper(int alpha_1[N], int alpha_2[N], int alpha_3[N]);
void copy_operation(int copy_number, int alpha, int Matrix[4][4], int R[20][4]);
void copyer(int Matrix[4][4][N], int alpha, int copy_number, int Register_Matrix[20][4][N]);
int Step1(int leng[opera_num]);
int Step2(int leng[opera_num]);
int path_depth(int pathtype, int D_temp[4], int D[4], int E[13], int r);
int main()
{
	clock_t begin, end;

	FILE* fpp = fopen("9n_1(0-1).txt", "a");
	if (NULL == fpp)
	{
		perror("FAIL");
		exit(1);
	}
	int path[opera_num] = { 14 };
	begin = clock();
	long long int num = 0, DEPTH = 0;
	int D_TEMP[9][4] = { 0 };
	for (path[1] = 0; path[1] < 20; path[1]++)
	{
		cout << "path[1]" << endl;
		int D_0[4] = { 0,0,1,0 }, E[13] = { 0,0,0,0,1 };
		DEPTH = path_depth(path[1], D_0, D_TEMP[1], E, 5);
		if (DEPTH > 3) continue;
		for (path[2] = 0; path[2] < 24; path[2]++)
		{
			
			DEPTH = path_depth(path[2], D_TEMP[1], D_TEMP[2], E, 6);
			if (DEPTH > 3)continue;
			for (path[3] = 0; path[3] < 28; path[3]++)
			{
				DEPTH = path_depth(path[3], D_TEMP[2], D_TEMP[3], E, 7);

				if (DEPTH > 3) continue;
				for (path[4] = 0; path[4] < 32; path[4]++)
				{
					DEPTH = path_depth(path[4], D_TEMP[3], D_TEMP[4], E, 8);
					if (DEPTH > 3) continue;
					for (path[5] = 0; path[5] < 36; path[5]++)
					{
						DEPTH = path_depth(path[5], D_TEMP[4], D_TEMP[5], E, 9);
						if (DEPTH > 3) continue;
						for (path[6] = 0; path[6] < 40; path[6]++)
						{
							DEPTH = path_depth(path[6], D_TEMP[5], D_TEMP[6], E, 10);
							if (DEPTH > 3) continue;
							for (path[7] = 0; path[7] < 44; path[7]++)
							{
								DEPTH = path_depth(path[7], D_TEMP[6], D_TEMP[7], E, 11);
								if (DEPTH > 3) continue;
								for (path[8] = 0; path[8] < 48; path[8]++)
								{
									DEPTH = path_depth(path[8], D_TEMP[7], D_TEMP[8], E, 12);
									if (DEPTH > 3) continue;
									else
									{
										//num++;
										int s1 = 0, s2 = 0;
										s1 = Step1(path);
										if (s1 == 1)
										{
											//num++;
											s2 = Step2(path);
											if (s2 == 1)
											{
												num++;
												for (int i = 0; i < opera_num; i++)
												{
													fprintf(fpp, "%d ", path[i]);
												}
												fprintf(fpp, "\n ");
											}
											
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	cout << num << endl;
	end = clock();
	cout << "time used: " << (double)(end - begin) / CLOCKS_PER_SEC << endl;
	printf("\n");
	return 0;
}

int path_depth(int pathtype, int D[4], int D_temp[4], int E[13], int r)
{

	int D1[4] = { 0 };

	for (int i = 0; i < 4; i++)
	{
		D_temp[i] = D[i];
	}


	if (D[copy_type[pathtype][1]] > E[copy_type[pathtype][2]])
	{
		D_temp[copy_type[pathtype][1]]++;
	}
	else
	{
		D_temp[copy_type[pathtype][1]] = E[copy_type[pathtype][2]] + 1;
	}
	E[r] = D_temp[copy_type[pathtype][1]];
	for (int i = 0; i < 4; i++)
	{
		D1[i] = D_temp[i];
	}
	for (int i = 0; i < 3; i++)
	{
		for (int j = i + 1; j < 4; j++)
		{
			if (D1[i] < D1[j])
			{
				int temp = D1[i]; D1[i] = D1[j]; D1[j] = temp;
			}
		}
	}



	return D1[0];
}


int Step1(int leng[opera_num])
{
	int B[4][4] = { 1,0,0,0,0,1,0,0,0,0,1,1,0,0,0,1 };
	int R[20][4] = { 0 };
	R[0][0] = 1, R[1][1] = 1, R[2][2] = 1, R[3][3] = 1, R[4][2] = 1, R[4][3] = 1;
	int r = 5;
	for (int i = 1; i < opera_num; i++)///Copy_opreation(leng[i], 1, B)
	{
		copy_operation(leng[i], 1, B, R);
		for (int j = 0; j < 4; j++)
		{
			R[r][j] = B[copy_type[leng[i]][1]][j];
		}
		r++;
	}
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			if (B[i][j] == 0)
			{
				return 0;

			}
		}
	}
	return 1;
}
void copy_operation(int copy_number, int alpha, int Matrix[4][4], int R[20][4])
{
	for (int i = 0; i < 4; i++)
	{
		Matrix[copy_type[copy_number][1]][i] = Matrix[copy_type[copy_number][1]][i] + R[copy_type[copy_number][2]][i] * alpha;
	}
}
int Step2(int leng[opera_num])
{
	// Let Temp_Matrix be a 4*4 matrix  and each  element can be expressed as sum array.  
	int Temp_Matrix[4][4][N] = { 0 };
	int Register_Matrix[13][4][N] = { 0 };
	Temp_Matrix[0][0][0] = Register_Matrix[0][0][0] = 1;
	Temp_Matrix[1][1][0] = Register_Matrix[1][1][0] = 1;
	Temp_Matrix[2][2][0] = Register_Matrix[2][2][0] = 1;
	Temp_Matrix[3][3][0] = Register_Matrix[3][3][0] = 1;
	Register_Matrix[4][2][0] = 1, Temp_Matrix[2][3][0] = Register_Matrix[4][3][0] = 2;
	int r = 5;
	//MP(Temp_Matrix);
	for (int i = 1; i < opera_num; i++)
	{
		copyer(Temp_Matrix, i + 1, leng[i], Register_Matrix);
		//MP(Temp_Matrix);
		for (int j = 0; j < 4; j++)
		{
			for (int k = 0; j < N; k++)
			{
				if (Temp_Matrix[copy_type[leng[i]][1]][j][k] == 0)break;
				Register_Matrix[r][j][k] = Temp_Matrix[copy_type[leng[i]][1]][j][k];
			}
		}
		r++;
	}
	int a = MDS(Temp_Matrix);
	return a;

}
void copyer(int Matrix[4][4][N], int alpha, int copy_number, int Register_Matrix[20][4][N])
{
	int temp1[4][N] = { 0 };
	int temp[N] = { Integer_power(alpha) };
	for (int i = 0; i < 4; i++)
	{
		multoper(temp, Register_Matrix[copy_type[copy_number][2]][i], temp1[i]);
		addoper(Matrix[copy_type[copy_number][1]][i], temp1[i], Matrix[copy_type[copy_number][1]][i]);
	}
}
int MDS(int Matrix_A[4][4][N])
{
	int hh[36][4] = {
	0,1,0,1,0,1,0,2,0,1,0,3,0,1,1,2,0,1,1,3,0,1,2,3,
	0,2,0,1,0,2,0,2,0,2,0,3,0,2,1,2,0,2,1,3,0,2,2,3,
	0,3,0,1,0,3,0,2,0,3,0,3,0,3,1,2,0,3,1,3,0,3,2,3,
	1,2,0,1,1,2,0,2,1,2,0,3,1,2,1,2,1,2,1,3,1,2,2,3,
	1,3,0,1,1,3,0,2,1,3,0,3,1,3,1,2,1,3,1,3,1,3,2,3,
	2,3,0,1,2,3,0,2,2,3,0,3,2,3,1,2,2,3,1,3,2,3,2,3
	};
	int gh1[16][3] = {
		0,1,3,0,2,4,1,2,5,3,4,5,
		0,1,3,0,2,4,1,2,5,3,4,5,
		6,7,9,6,8,10,7,8,11,9,10,11,
		18,19,21,18,20,22,19,20,23,21,22,23
	};

	int gh2[16][3] = {
		2,1,0,3,1,0,3,2,0,3,2,1,
		2,1,0,3,1,0,3,2,0,3,2,1,
		2,1,0,3,1,0,3,2,0,3,2,1,
		2,1,0,3,1,0,3,2,0,3,2,1
	};
	int hg[4][3] = {
		0, 1, 2, 0, 1, 3, 0, 2, 3, 1, 2, 3 };
	int c[N] = { 0 }, d[N] = { 0 }, e[N] = { 0 }, f[N] = { 0 }, g[N] = { 0 };
	int temp[36][N];
	int tt = 0;
	// Verify the determinants of the 36 submatrices of order two 
	for (int i = 0; i < 36; i++)
	{
		multoper(Matrix_A[hh[i][0]][hh[i][2]], Matrix_A[hh[i][1]][hh[i][3]], c);
		multoper(Matrix_A[hh[i][1]][hh[i][2]], Matrix_A[hh[i][0]][hh[i][3]], d);
		addoper(c, d, e);
		int t = 0;
		for (int j = 0; j < N; j++)
		{
			temp[i][j] = e[j];
			if (e[j] > 0)
			{
				t = t + 1;

			}

		}
		if (t > 0)
		{
			tt = tt + 1;
		}
		else { return 0; }
	}
	if (tt == 36)
	{
		// Verify the determinants of the 16 submatrices of order three 
		for (int i = 0; i < 4; i++)
		{
			multoper(temp[gh1[i][0]], Matrix_A[2][gh2[i][0]], c);
			multoper(temp[gh1[i][1]], Matrix_A[2][gh2[i][1]], d);
			multoper(temp[gh1[i][2]], Matrix_A[2][gh2[i][2]], e);
			addoper(c, d, f);
			addoper(e, f, g);
			int t = 0;
			for (int j = 0; j < N; j++)
			{

				if (g[j] > 0)
				{
					t = t + 1;
					//printf("%d,", g[j]);
				}
			}
			//printf("\n");

			if (t > 0)
			{
				tt = tt + 1;

			}
			else { return 0; }

		}

		for (int i = 4; i < 16; i++)
		{
			multoper(temp[gh1[i][0]], Matrix_A[3][gh2[i][0]], c);
			multoper(temp[gh1[i][1]], Matrix_A[3][gh2[i][1]], d);
			multoper(temp[gh1[i][2]], Matrix_A[3][gh2[i][2]], e);
			addoper(c, d, f);
			addoper(e, f, g);
			int t = 0;
			for (int j = 0; j < N; j++)
			{
				if (g[j] > 0)
				{
					t = t + 1;
				}

			}
			//printf("\n");
			if (t > 0)
			{
				tt = tt + 1;

			}
			else { return 0; }
		}
		//return  1;
	}
	return  1;
}
void multoper(int alpha_1[N], int alpha_2[N], int alpha_3[N])
{

	int t1 = 0;
	int t2 = 0;
	for (int i = 0; i < N; i++)
	{
		if (alpha_1[i] > 0)
		{
			t1 = t1 + 1;
		}
		if (alpha_2[i] > 0)
		{
			t2 = t2 + 1;
		}
	}
	int d[N] = { 0 };
	int temp[N] = { 0 };
	int t = 0;
	for (int i = 0; i < t1; i++)
	{
		for (int j = 0; j < t2; j++)
		{
			t = alpha_1[i] | alpha_2[j];
			d[t] = d[t] ^ 1;

		}
	}

	t = 0;
	for (int i = N; i >= 0; i--)
	{
		if (d[i] == 1)
		{

			temp[t] = i;
			t = t + 1;

		}
	}

	for (int i = 0; i < N; i++)
	{
		alpha_3[i] = temp[i];
		//printf("%d\n", a[i]);
	}


}
void addoper(int alpha_1[N], int alpha_2[N], int alpha_3[N])
{

	int c[N] = { 0 };
	int t1 = 0;
	int t2 = 0;
	int t = 0;
	for (int i = 0; i < N; i++)
	{
		if (alpha_1[t1] > alpha_2[t2])
		{
			c[t] = alpha_1[t1];
			t1 = t1 + 1;
			t = t + 1;
		}
		else if (alpha_1[t1] < alpha_2[t2])
		{
			c[t] = alpha_2[t2];
			t2 = t2 + 1;
			t = t + 1;
		}
		else {
			t1 = t1 + 1;
			t2 = t2 + 1;
		}


	}
	for (int i = 0; i < N; i++)
	{
		alpha_3[i] = c[i];
	}

}



int Integer_power(int num)
{
	int s = 1;
	for (int i = 0; i < num; i++)
	{
		s = s * 2;
	}
	return s;

}


